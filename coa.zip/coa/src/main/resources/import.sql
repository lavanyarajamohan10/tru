ALTER SEQUENCE hibernate_sequence RESTART WITH 1;

DELETE FROM COMPANY;
DELETE FROM OFFICER;
DELETE FROM ADDRESS;

INSERT INTO COMPANY(company_id,company_number,company_status,company_type,date_of_creation,title,address_id,officer_id) VALUES (1, 06500244,'active','ltd','2011-02-07','BBC LIMITED',01,100);

INSERT INTO OFFICER (officer_id,name,officer_role,appointed_on,address_id) VALUES (1, 'BOXALL,Sarah Victoria', 'secretary','2008-02-11',02);

INSERT INTO ADDRESS (address_id,locality, postal_code,premises,address_line_1,country)VALUES (01, 'Retford', 'DN22 0AD','Boswell Cottage main street','North Levrton','England');
INSERT INTO ADDRESS (address_id,locality, postal_code,premises,address_line_1,country)VALUES (02, 'London', 'SW20 0DP','carlton terrace','cranford close','England');