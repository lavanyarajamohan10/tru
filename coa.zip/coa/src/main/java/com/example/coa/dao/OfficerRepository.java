package com.example.coa.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.coa.domain.Officer;

public interface OfficerRepository extends JpaRepository<Officer, Integer>{

}
