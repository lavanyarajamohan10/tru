package com.example.coa.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.coa.domain.Company;


public interface CompanyRepository extends JpaRepository<Company,Integer>{
    @Query("select c from Company c where c.title=?1 and c.company_number=?2")
    public  List<Company> searchByCompAndOffi(String title,long  companyNumber); 
	
}
