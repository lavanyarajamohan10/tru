package com.example.coa.domain;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
@Entity
public class Company implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long company_id;

	private long company_number;
	private String company_type;
	private String title;
	private String company_status;
	private LocalDateTime date_of_creation;
	
	@ManyToOne
	@JoinColumn(name = "address_id", referencedColumnName = "address_id")
	private Address address;

	@ManyToOne
	@JoinColumn(name = "officer_id", referencedColumnName = "officer_id")
	private Officer officer;

	public Company() {
	}

	public long getCompany_id() {
		return company_id;
	}

	public void setCompany_id(long company_id) {
		this.company_id = company_id;
	}

	public long getCompany_number() {
		return company_number;
	}

	public void setCompany_number(long company_number) {
		this.company_number = company_number;
	}

	public String getCompany_type() {
		return company_type;
	}

	public void setCompany_type(String company_type) {
		this.company_type = company_type;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCompany_status() {
		return company_status;
	}

	public void setCompany_status(String company_status) {
		this.company_status = company_status;
	}

	public LocalDateTime getDate_of_creation() {
		return date_of_creation;
	}

	public void setDate_of_creation(LocalDateTime date_of_creation) {
		this.date_of_creation = date_of_creation;
	}

	

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Officer getOfficer() {
		return officer;
	}

	public void setOfficer(Officer officer) {
		this.officer = officer;
	}

	@Override
	public String toString() {
		return "Company [company_id=" + company_id + ", company_number=" + company_number + ", company_type="
				+ company_type + ", title=" + title + ", company_status=" + company_status + ", date_of_creation="
				+ date_of_creation + ", address=" + address + ", officer=" + officer + "]";
	}

}