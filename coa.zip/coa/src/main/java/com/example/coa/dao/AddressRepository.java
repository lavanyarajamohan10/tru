package com.example.coa.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.coa.domain.Address;

public interface AddressRepository extends JpaRepository<Address, Integer>{

}
