package com.example.coa.controller;

import static org.springframework.web.bind.annotation.RequestMethod.GET;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.coa.domain.Company;
import com.example.coa.domain.Officer;
import com.example.coa.service.CompanyService;

import net.bytebuddy.asm.Advice.Return;

@RestController
@RequestMapping("/truProxyAPI/rest/Companies/v1")
public class CompanyController {

	@Autowired
	CompanyService companyService;

//Application setup check
	@RequestMapping(method = GET, path = "/hello")
	public String getHelloString() {
		return "Hello";
	}

//get all employee

	@RequestMapping(method = GET, path = "/getAllCompany", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getAllCompany(@RequestBody(required=false) String title, long companyNumber) {
		JSONObject jso = null;
		//JSONArray jsa = new JSONArray();
		List<Company> alist = companyService.getAllCompany(title, companyNumber);

		for (Company comp : alist) { 
			jso = new JSONObject();
			// company
			jso.put("company_number", comp.getCompany_number());
			jso.put("company_type", comp.getCompany_type());
			jso.put("title", comp.getTitle());
			jso.put("company_status", comp.getCompany_status());
			jso.put("date_of_creation", comp.getDate_of_creation());

			// company address
			jso.put("locality", comp.getAddress().getLocality());
			jso.put("postal_code", comp.getAddress().getPostal_code());
			jso.put("premises", comp.getAddress().getPremises());
			jso.put("address_line_1", comp.getAddress().getAddress_line_1());
			jso.put("country", comp.getAddress().getCountry());

			// officer 
			jso.put("name", comp.getOfficer().getName());
			jso.put("officer_role", comp.getOfficer().getOfficer_role());
			jso.put("appointed_on", comp.getOfficer().getAppointed_on());

			// office address jso.put("locality",company.getLocality());
			jso.put("postal_code", comp.getOfficer().getAddress().getPostal_code());
			jso.put("premises", comp.getOfficer().getAddress().getPremises());
			jso.put("address_line_1", comp.getOfficer().getAddress().getAddress_line_1());
			jso.put("country", comp.getOfficer().getAddress().getCountry());
			

		}

		return new ResponseEntity<>(jso.toMap(), HttpStatus.OK);

	}
	/*
	 * //get all employee officer company details
	 * 
	 * @RequestMapping(method = GET, path = "/getAll") public List<Company>
	 * getCompOffAddr() { return companyService.getCompOffAddr();
	 * 
	 * }
	 */
}
