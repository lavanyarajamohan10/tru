package com.example.coa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.coa.dao.CompanyRepository;
import com.example.coa.domain.Company;


@Service
public class CompanyService {
@Autowired 
CompanyRepository companyRepository;

public List<Company> getAllCompany(String title, long companyNumber) {
	return companyRepository.searchByCompAndOffi(title,companyNumber);
}

}
