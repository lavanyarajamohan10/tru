package com.example.coa.domain;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
@Entity
public class Officer implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private long officer_id;
	private String name;
	private String officer_role;
	private String appointed_on;
	@ManyToOne
	@JoinColumn(name = "address_id", referencedColumnName = "address_id")
	private Address address;


	@OneToMany(mappedBy = "officer", cascade = CascadeType.ALL, orphanRemoval = true

	)

	@JsonIgnore
	private List<Company> company;

	public Officer(long officer_id, String name) {
		super();
		this.officer_id = officer_id;
		this.name = name;
	}

	public Officer() {
	}

	public long getOfficer_id() {
		return officer_id;
	}

	public void setOfficer_id(int officer_id) {
		this.officer_id = officer_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOfficer_role() {
		return officer_role;
	}

	public void setOfficer_role(String officer_role) {
		this.officer_role = officer_role;
	}

	public String getAppointed_on() {
		return appointed_on;
	}

	public void setAppointed_on(String appointed_on) {
		this.appointed_on = appointed_on;
	}

	

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public List<Company> getCompany() {
		return company;
	}

	public void setCompany(List<Company> company) {
		this.company = company;
	}

}
